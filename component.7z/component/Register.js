import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import $ from 'jquery';
import Validation from './Validation';

class Register extends Component{
  constructor (props) {
    super(props);
    this.state = {
      username:'',
      password: '',
      email: '',      
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    // this.Validation = this.Validation.bind(this);

  }
  handleChange(e){
    const name =e.target.name;
    const value= e.target.value;
    this.setState({
        [name]:value
    });
  }
  handleSubmit(e){
    e.preventDefault();
    alert(Validation.ValidateRegister());
    
  }
 
  render(){
    return(    
      <div className=" height  fixed-top">
        <div className='box d-flex align-items-center justify-content-center'>
          <form className='register' onSubmit={this.handleSubmit}>
                <h3>Register User</h3>
                <div className='pb-2 '>
                  <label className=' text-left float-left d-block' >Username</label>
                  <input className='' type="text" name="username" onChange={this.handleChange} />
                  <small>Username must can't be blank..!</small>
                </div>
                <div className='pb-2'>
                  <label className=' text-left float-left d-block' >Password</label>
                  <input type="text" name="password" onChange={this.handleChange} />
                  <small>Password must can't be blank..!</small>
                </div>
                <div className='pb-2'>
                  <label className=' text-left float-left d-block' >Email</label>
                  <input type="text" name="email" onChange={this.handleChange}/>
                  <small>Email must can't be blank..!</small>
                </div>
                <div className='pt-2 text-center'>
                  <button className='text-center btn btn-secondary'>Submit</button>
                </div>              
          </form>
        </div>        
      </div>        
    );
  }
}

export default Register;