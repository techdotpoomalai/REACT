import React, { Component } from 'react';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import { faCopy, faPaste } from '@fortawesome/free-solid-svg-icons';
import $ from "jquery";

class Login extends Component{
  constructor (props) {
    super(props);
    this.state = {
      username:'',
      password: '',
    }
  }
  render(){
    return(
      <div className='align-items-center justify-content-center'>
        <div className="token-filed d-flex justify-content-center">
          <div className="block">
          {/* ????????????????????????????????????????????????????????????????????????????????????????????????????? */}
            <div className="singin">
              <form >
                <div className='p-2'>
                  <label className='px-1'>Username</label>
                  <input type="text" name="username" />
                </div>
                
                <div className='p-2'>
                  <label className='px-1'>Password</label>
                  <input type="text" name="password" />
                </div>
                
                <div className='pt-3 text-center'>
                  <button className='text-center btn btn-dark text-wrap '>Get token</button>
                </div>
              </form>
            </div>
              {/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */}
            <div>
              <div className='block_input'>
                  <input type="text" id="token" value=""/>
                  <div className='icon' >
                    <span className='span-copy' tooltip="Copy"><FontAwesomeIcon  icon={faCopy} /></span>
                  </div>
              </div>
              <div className='space'></div>  
              <div className='block_input1'>                
                <input type="text" id="token1" value="" placeholder='Paste Here...'/>
                <div className='icon'>
                  <span className='span-copy' tooltip="Paste"><FontAwesomeIcon className='span-copy' icon={faPaste} /></span>
                </div>
              </div>
              <div className='space2'></div>
              <div className='block_input' id="btn"><button type="button" class="btn btn-primary" >Submit</button></div>
            </div> 
          {/* ????????????????????????????????????????????????????????????????????????????????????????????????????? */}
          </div>
        </div>
      </div>
    );
  }
}

export default Login;